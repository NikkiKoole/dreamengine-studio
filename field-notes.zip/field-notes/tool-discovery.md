# Tool Discovery and Documentation

## Purpose

DreamEngine contains a growing set of local tools.

These tools help with carts, documentation, builds, validation, indexes, audio analysis, site generation and other repository maintenance tasks.

As the number of tools grows, it becomes harder for humans and AI agents to know:

* what tools exist
* when to use them
* whether they are safe to run
* what inputs they expect
* what files they modify

This document defines a lightweight convention for making tools easier to discover and use.

## Principle

Tools should describe themselves.

We do not want a separate manifest that has to be manually kept in sync with the actual scripts.

Instead, each tool should include a small metadata header near the top of the file.

That header becomes the single source of truth.

From those headers we can later generate:

* a human-readable tool index
* AI-facing tool documentation
* command help output
* safety summaries
* repository maintenance guides

## Tool Header Convention

Each tool should start with a small comment block.

Example:

```js
#!/usr/bin/env node

/**
 * @tool cart-info
 * @summary Orient yourself on one cart.
 * @category carts
 * @when Before modifying or investigating a cart.
 * @safe read-only
 *
 * Usage:
 *   node tools/cart-info.js <cart-name>
 */
```

## Fields

### `@tool`

Stable tool name.

Example:

```text
cart-info
```

### `@summary`

One sentence explaining what the tool does.

### `@category`

Broad grouping.

Suggested categories:

* carts
* build
* docs
* site
* lint
* audio
* analysis
* maintenance

### `@when`

When a human or AI agent should use this tool.

This is often more useful than a technical description.

### `@safe`

Safety level.

Suggested values:

* `read-only`
* `modifies-docs`
* `modifies-generated-files`
* `modifies-source`
* `destructive`

## Generated Tool Index

A future script can scan `tools/` and generate:

```text
docs/tools.md
```

This generated file should list all known tools grouped by category.

Example output:

````md
# Tool Index

## Carts

### cart-info

Orient yourself on one cart.

When to use:

- Before modifying or investigating a cart.

Safety:

- read-only

Command:

```sh
node tools/cart-info.js <cart-name>
````

```

## Why This Helps Agents

AI agents often fail because they do not know which local tools exist.

A generated tool index gives agents a reliable map of the repository toolbelt.

Instead of guessing, an agent can first read the tool index and decide:

- which tool is relevant
- whether it is safe
- whether it should run before or after editing
- whether it validates the work

## Adoption

This convention should be introduced gradually.

Existing tools do not need to be updated all at once.

When a tool is edited, add or improve its header.

New tools should include the header from the start.

## Future Work

Possible next steps:

1. Add headers to the most important tools.
2. Write a small `tool-index` generator.
3. Generate `docs/tools.md`.
4. Add tool index checks to documentation linting.
5. Let AI agents use the generated index as part of their startup context.

The goal is not to create a heavy tool framework.

The goal is to make the existing toolbelt visible, searchable and safe to use.
```
